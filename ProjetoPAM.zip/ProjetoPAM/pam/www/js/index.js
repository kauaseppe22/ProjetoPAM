var app = {
        

    initialize: function() {
        document.addEventListener('deviceready', this.onDeviceReady.bind(this), false);
    },

    onDeviceReady: function() {
        document.getElementById("btnInserir").addEventListener("click",app.inserir);
        document.getElementById("btnListar").addEventListener("click",app.listar);
        this.receivedEvent('deviceready');
    },

    receivedEvent: function(id) {
        banco = window.sqlitePlugin.openDatabase({
            name: 'ProjetoPam',
            location: 'default',            
            androidDatabaseProvider: 'system'
        });

        banco.transaction(function(tx) {
            tx.executeSql('CREATE TABLE IF NOT EXISTS usuarios (nome, RG, tel, end)');
        }, function(error) {
            console.log('Transaction ERROR: ' + error.message);
        }, function() {
            alert('Banco e Tabela criados com sucesso!');
        });
    },

    inserir: function(){
        let nome = document.getElementById("txtnome").value;
        let RG = document.getElementById("txtRG").value;
        let tel = document.getElementById("txttel").value;
        let end = document.getElementById("txtend").value;

        banco.transaction(function(tx) {
            tx.executeSql('INSERT INTO usuarios VALUES (?,?)', [nome, RG, tel, end]);
        }, function(error) {
            alert('Erro durante a transacao com o banco: ' + error.message);
        }, function() {
            alert('Insercao realizada com sucesso!');
        });
    },
    
    
        
        };
        
        
        
        app.initialize();